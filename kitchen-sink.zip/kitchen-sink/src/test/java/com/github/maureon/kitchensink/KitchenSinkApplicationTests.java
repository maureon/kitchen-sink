package com.github.maureon.kitchensink;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KitchenSinkApplicationTests {

	@Test
	void contextLoads() {
	}

}
