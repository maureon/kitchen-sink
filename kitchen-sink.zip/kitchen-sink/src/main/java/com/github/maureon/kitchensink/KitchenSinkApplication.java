package com.github.maureon.kitchensink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KitchenSinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(KitchenSinkApplication.class, args);
	}

}
